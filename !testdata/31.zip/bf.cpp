#include<bits/stdc++.h>
using namespace std;
const int CN = 1e6 + 10;
int read(){
    int s = 0, ne = 1; char c = getchar();
    for(;c < '0' || c > '9';c = getchar()) if(c == '-') ne = -1;
    for(;c >= '0' && c <= '9';c = getchar()) s = (s << 1) + (s << 3) + c - '0';
    return s * ne;
}
int n, q; char ch[CN];
bool ck(int l, int r, int len){
    for(int i = l; i + len <= r; i++) if(ch[i] != ch[i + len]) return 0;
    return 1;
}
bool found(int l, int r){
    for(int i = 1; 2 * i <= r - l + 1; i++){
        if(ck(l, r, i)){
            printf("%d\n", i);
            return 1;
        }
    }
    return 0;
}
int main()
{
    freopen("squaren.in", "r", stdin);
    freopen("squaren.out", "w", stdout);
    n = read(), scanf("%s", ch + 1);
    q = read();
    while(q--){
        int l = read(), r = read();
        if(!found(l, r)) puts("-1");
    }
    return 0;
}