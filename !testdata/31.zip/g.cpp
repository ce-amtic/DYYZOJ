#include<bits/stdc++.h>
using namespace std;
int read(){
    int s = 0, ne = 1; char c = getchar();
    for(;c < '0' || c > '9';c = getchar()) if(c == '-') ne = -1;
    for(;c >= '0' && c <= '9';c = getchar()) s = (s << 1) + (s << 3) + c - '0';
    return s * ne;
}
int g(int l, int r) {return rand() % (r - l + 1) + l;}
int main()
{
    freopen("squaren10.in", "w", stdout);
    int *sd = new int; srand(time(0) + clock() + *sd);
    int n = 1000000, q = g(n - 10, n), B = ceil(pow(n, 0.43333)), l = 1, r = n;
    if(q == 1) l = g(1, B), r = g(n - B + 1, n);
    printf("%d\n", n);
    int cnt = 0, len = g(1, B);
    while(cnt + 1 < l){
        putchar("abcdefghijklmnopqrstuvwxyz"[g(0, 25)]);
        cnt++;
    }
    char a = 'a', b = 'b', c = 'c';
    while(cnt < r){
        // if(!g(0, 10)) putchar("abcdef"[g(0, 5)]), cnt++;
        // else{
            int i = 0; while(cnt < n && i < len) putchar(a), cnt++, i++;
            i = 0; while(cnt < n && i < len) putchar(b), cnt++, i++;
            i = 0; while(cnt < n && i < len) putchar(c), cnt++, i++;
            if(!g(0, 9)){
                len = g(1, B);
                a = 'a' + g(0, 25), b = 'a' + g(0, 25), c = 'a' + g(0, 25);
            }
        // }
    }
    while(cnt < n){
        putchar("abcdefghijklmnopqrstuvwxyz"[g(0, 25)]);
        cnt++;        
    }
    puts("");
    printf("%d\n", q);
    if(q == 1){
        printf("%d %d\n", l, r);
        return 0;
    }
    for(int i = 1; i <= q; i++){
        if(!g(0, 3)){
            int l = g(1, n);
            printf("%d %d\n", l, g(l, n));
        }
        else{
            int l = g(1, B), r = g(n - B + 1, n);
            printf("%d %d\n", l, r);
        }
    }
}