#include<bits/stdc++.h>
using namespace std;
int g(int l, int r) {return (rand() * 32768 + rand()) % (r - l + 1) + l;}
void small(){
	int n = g(500, 1000), q = g(500, 1000), B = ceil(sqrt(1e9));
	printf("%d %d\n", n, q);
	for(int i = 1; i <= n; i++){
		int x = g(0, 2), l, r;
		if(!x) l = g(1, 1e9), r = g(l, 1e9);
		if(x == 1) l = g(1, B), r = g(l, B);
		if(x == 2) l = g(1, B), r = g(B, 1e9);
		printf("%d %d\n", l, r);
	}
	B = ceil(sqrt(n));
	for(int i = 1; i <= q; i++){
		int x = g(0, 2), l, r;
		if(!x) l = g(1, n), r = g(l, n);
		if(x == 1) l = g(1, B), r = g(l, B);
		if(x == 2) l = g(1, B), r = g(B, n);
		printf("%d %d\n", l, r);
	}
}
void big(){
	int n = g(150000, 200000), q = g(150000, 200000), B = ceil(sqrt(1e9));
	printf("%d %d\n", n, q);
	for(int i = 1; i <= n; i++){
		int x = g(0, 2), l, r;
		if(!x) l = g(1, 1e9), r = g(l, 1e9);
		if(x == 1) l = g(1, B), r = g(l, B);
		if(x == 2) l = g(1, B), r = g(B, 1e9);
		printf("%d %d\n", l, r);
	}
	B = ceil(sqrt(n));
	for(int i = 1; i <= q; i++){
		int x = g(0, 2), l, r;
		if(!x) l = g(1, n), r = g(l, n);
		if(x == 1) l = g(1, B), r = g(l, B);
		if(x == 2) l = g(1, B), r = g(B, n);
		printf("%d %d\n", l, r);
	}
}
int main(){
	freopen("cov.in", "w", stdout); int *sd = new int; srand(time(0) + *sd + clock());
    small();
	return 0;
} 
