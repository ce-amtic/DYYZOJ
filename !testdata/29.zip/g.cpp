#include<bits/stdc++.h>
using namespace std;
int g(int l, int r) {return (rand() * 32768 + rand()) % (r - l + 1) + l;}
int main()
{
	freopen("count3.in", "w", stdout);
	int *seed = new int; srand(time(0) + clock() + *seed);
	int n = g(11, 15), m = g(1, 7);
	printf("%d %d\n", n, m);
}
