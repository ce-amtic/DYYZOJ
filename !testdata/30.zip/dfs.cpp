#include<bits/stdc++.h>
using namespace std;
const int P = 191011109;
int read(){
    int s = 0, ne = 1; char c = getchar();
    for(;c < '0' || c > '9';c = getchar()) if(c == '-') ne = -1;
    for(;c >= '0' && c <= '9';c = getchar()) s = (s << 1) + (s << 3) + c - '0';
    return s * ne;
}
int add(int x, int y) {return x + y >= P ? x + y - P : x + y;}
int n, m, t[101], tt[101], a[101], ans = 0;
map<int, bool> vis;
int hash(int a[]){
    int r = 0;
    for(int i = 1; i <= n; i++) r = add(a[i], 13ll * r % P);
    return r;
}
void tag(int a[]){
    for(int p = 1; p <= n; p++){
        for(int i = p; i <= n; i++) t[i - p + 1] = a[i];
        for(int i = 1; i < p; i++) t[n - p + i + 1] = a[i];
        for(int k = 0; k < m; k++){
            for(int i = 1; i <= n; i++) tt[i] = t[i] + k >= m ? t[i] + k - m : t[i] + k;
            vis[hash(tt)] = 1;
        }
    }
}
void dfs(int pos){
    if(pos > n){
        if(!vis.count(hash(a))) ans++, tag(a);
         return;
    }
    for(int i = 0; i < m; i++) a[pos] = i, dfs(pos + 1);
}
int main()
{
    freopen("paint.in", "r", stdin);
    freopen("paint.out", "w", stdout);
    n = read(), m = read();
    dfs(1), printf("%d", ans);
    fclose(stdin), fclose(stdout);
    return 0;
}