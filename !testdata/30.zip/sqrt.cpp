#include<bits/stdc++.h>
using namespace std;
#define int long long
const int P = 1004535809;
int read(){
    int s = 0, ne = 1; char c = getchar();
    for(;c < '0' || c > '9';c = getchar()) if(c == '-') ne = -1;
    for(;c >= '0' && c <= '9';c = getchar()) s = (s << 1) + (s << 3) + c - '0';
    return s * ne;
}
int add(int a, int b) {return a + b >= P ? a + b - P : a + b;}
int mul(int a, int b) {return (__int128)a * b % P;}
int qp(int a, int b){
    a %= P, b %= P; int r = 1;
    while(b){
        if(b & 1) r = mul(r, a);
        a = mul(a, a), b >>= 1;
    }
    return r;
}
int gcd(int a, int b) {return a >= 0 ? (b ? gcd(b, a % b) : a) : gcd(-a, b);}
int n, m, ans = 0;
int phi(int x){
    int t = x, r = x;
    for(int d = 2; d * d <= x; d++){
        if(t % d) continue;
        while(!(t % d)) t /= d;
        r /= d, r *= (d - 1);
    }
    if(t > 1) r /= t, r *= (t - 1);
    return r % P;
}
void work(int d){
    int cur = mul(qp(m, d), phi(n / d));
    ans = add(ans, mul(cur, gcd(m, n / d)));
}
signed main()
{
    freopen("paint.in", "r", stdin);
    freopen("paint.out", "w", stdout);
    n = read(), m = read();
    for(int d = 1; d * d <= n; d++){
        if(n % d) continue;
        work(d); if(d ^ (n / d)) work(n / d);
    }
    ans = mul(ans, qp(mul(n, m), P - 2));
    printf("%d", ans);
    fclose(stdin), fclose(stdout);
    return 0;
}