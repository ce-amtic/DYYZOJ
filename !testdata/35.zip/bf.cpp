#pragma GCC optimize(1, 2, 3, "Ofast")
#pragma G++ optimize(1, 2, 3, "Ofast")
#include<bits/stdc++.h>
using namespace std;
#define pb push_back
const int CN = 5e5 + 10;
int read(){
    int s = 0, ne = 1; char c = getchar();
    for(;c < '0' || c > '9';c = getchar()) if(c == '-') ne = -1;
    for(;c >= '0' && c <= '9';c = getchar()) s = (s << 1) + (s << 3) + c - '0';
    return s * ne;
}
int n, m, q, c[CN], dep[CN]; vector<int> G[CN]; queue<int> Q; bool vis[CN];
int ck[CN];
int mex(){
    for(int i = 0; i < n; i++) if(!ck[i]) return i;
    return n;
}
void dfs(int u, int t, int dist, int &ans){
    if(dist > n) return;
    ck[c[u]]++;
    if(u == t){
        if(dist == dep[t]) ans = min(ans, mex());
        return;
    }
    for(int l = G[u].size(), i = 0; i < l; i++){
        int v = G[u][i]; dfs(v, t, dist + 1, ans);
    }
    ck[c[u]]--;
}
int val(int u){
    memset(ck, 0, sizeof(ck));
    int ans = n; dfs(1, u, 0, ans);
    return ans;
}
int main()
{
    freopen("minmex.in", "r", stdin);
    freopen("minmex.out", "w", stdout);
    n = read(), m = read(), q = read();
    for(int i = 1; i <= n; i++) c[i] = read();
    for(int i = 1; i <= m; i++){
        int u = read(), v = read(); 
        G[u].pb(v), G[v].pb(u);
    }
    Q.push(1);
    while(!Q.empty()){
        int u = Q.front(); Q.pop();
        if(vis[u]) continue; vis[u] = 1;
        for(int l = G[u].size(), i = 0; i < l; i++){
            int v = G[u][i]; if(vis[v]) continue;
            if(!dep[v]) dep[v] = dep[u] + 1, Q.push(v);
        }
    }
    while(q--){
        int u = read(), v = read(), ans = 0; swap(c[u], c[v]);
        for(int i = 1; i <= n; i++) ans = max(ans, val(i));
        printf("%d\n", ans);
    }
    return 0;
}
