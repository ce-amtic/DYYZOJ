#include<bits/stdc++.h>
using namespace std;
int g(int l, int r) {return rand() % (r - l + 1) + l;}
int main()
{
    freopen("minmex1.in", "w", stdout); int *sd = new int; srand(time(0) + *sd + clock());
    int n = g(50000, 100000), m = n + g(0, 50000), q = g(max(0, n - 500), n);
    printf("%d %d %d\n", n, m, q);
    int id[1000010]; for(int i = 0; i < n; i++) id[i + 1] = i;
    // random_shuffle(id + 1, id + n + 1);
    for(int i = 1; i <= n; i++) printf("%d ", id[i]); puts("");
    for(int i = 1; i <= n; i++) printf("%d %d\n", i, i ^ n ? i + 1 : 1);
    for(int i = 1; i <= m + q; i++){
        int u = g(1, n), v = g(1, n);
        printf("%d %d\n", u, v);
    }
    return 0;
}