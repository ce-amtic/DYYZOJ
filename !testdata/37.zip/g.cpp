#include<bits/stdc++.h>
using namespace std;
int g(int l, int r) {return rand() % (r - l + 1) + l;}
int main(){
    freopen("ctl3.in", "w", stdout); srand(time(0)); int N = g(5e5, 1e6);
    while(N--) putchar("aaaaaaaaaaabcdeabcdeabcdefghijklmnopqrstuvwxyz"[g(0, 45)]); puts("");
}