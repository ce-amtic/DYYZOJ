#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int main(){
	freopen("user_out", "r", stdin);
	long long Ti, Sz;
	string ans; cin >> ans; cin >> Ti >> Sz;
	cerr << "[spj]:info:Input user_out data successfully!" << endl;
	if(ans == "your answer is not correct!") {
		cerr << "[spj]:error:" << ans << endl;
		cout << 0 << endl;
		return 0;
	} else {
		FILE* F = fopen("answer", "r");
		int crrTi; fscanf(F, "%d", &crrTi);
		if(Ti > crrTi) { cout << 0 << endl; cerr << "[spj]:error:The number of `query` calls exceeds the limit."; }
		else {
			int ans = 0;
			for(int i = 0; i < 10; i++) { int x;fscanf(F, "%d", &x); ans += (Sz <= x); }
			cout << ans * 10 << endl;
			cerr << "[spj]:info:get " << ans << " pts " << endl;
		}
	}
	return 0;
}

