#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<ctime>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
void _wa(char *ch){
	printf("%s\n",ch);
	exit(0);
}
void _ac(int cnt,int size){
	printf("correct!\n%d %d\n",cnt,size);
	exit(0);
}
int _testid,_n,_k,_p,_cnt,_size;
int _tmp;
bool _chk[1010],_win,_find;
bool query(vector<int> chk){
	++_cnt;
	memset(_chk,0,sizeof(_chk));_find = 0;
	int size = chk.size();
	for(int i = 0;i < size;++i){
		if(chk[i] < 0 || chk[i] >= _n || _chk[chk[i]])
			_wa("invalid query!");
		_chk[chk[i]] = 1;
		if(chk[i] == _p) _find = 1; 
	}
	if(_tmp == _k - 1 || (rand() & 1)){
		_tmp = 0;
		return _find;
	}
	++_tmp;
	return !_find;
}
vector<int> guess(int testid,int n,int k);
int main(){
	srand(time(0) + 233333);
	string str; cin >> str;int ___;
	scanf("%d%d%d%d%d",&___, &_testid,&_n,&_k,&_p);
	vector<int> _ans = guess(_testid,_n,_k);
	_size = _ans.size();memset(_chk,0,sizeof(_chk));
	for(int i = 0;i < _size;++i){
		if(_ans[i] < 0 || _ans[i] >= _n || _chk[_ans[i]])
			_wa("invalid answer!");
		_chk[_ans[i]] = 1;
		if(_ans[i] == _p) _win = 1;
	}
	if(_win) _ac(_cnt,_size);
	else _wa("your answer is not correct!");
	return 0;
}
